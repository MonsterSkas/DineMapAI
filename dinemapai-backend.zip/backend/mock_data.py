"""
mock_data.py
-----------------------------------------------------------
Sample data for the DineMapAI dashboard.

This mirrors the mock data already used on the frontend
(js/api.js -> getMockDashboardData()) so the JSON keys match
exactly. That way you can flip USE_MOCK_DATA to false in the
frontend and the page keeps working without any changes to
dashboard.js.

Once you have a real database, replace the values in
get_dashboard_data() with a query — just keep the same
dictionary shape.
"""


def get_dashboard_data():
    """Returns everything the dashboard page needs to render."""
    return {
        "success": True,
        "user": {
            "name": "DR",
            "location": "Kolkata, West Bengal",
        },
        "timingPerformance": [
            {"label": "Morning", "time": "6 AM - 11 AM", "score": 72, "status": "Good", "color": "green"},
            {"label": "Afternoon", "time": "11 AM - 4 PM", "score": 85, "status": "Very Good", "color": "blue"},
            {"label": "Evening", "time": "4 PM - 10 PM", "score": 94, "status": "Excellent", "color": "purple"},
            {"label": "Night", "time": "10 PM - 2 AM", "score": 68, "status": "Moderate", "color": "orange"},
        ],
        "demandTrend": [
            {"hour": "12 AM", "value": 8},
            {"hour": "4 AM", "value": 4},
            {"hour": "8 AM", "value": 52},
            {"hour": "12 PM", "value": 48},
            {"hour": "4 PM", "value": 78},
            {"hour": "8 PM", "value": 92},
            {"hour": "12 AM", "value": 30},
        ],
        "topLocations": [
            {"rank": 1, "letter": "A", "name": "Lake Gardens", "score": 91,
             "desc": "High college density • Good connectivity • Low competition", "color": "#7c5cfc"},
            {"rank": 2, "letter": "B", "name": "Jadavpur", "score": 87,
             "desc": "High footfall • Near universities • Good transport", "color": "#3b82f6"},
            {"rank": 3, "letter": "C", "name": "Salt Lake Sector V", "score": 82,
             "desc": "Office crowd • High demand • Moderate competition", "color": "#22c55e"},
            {"rank": 4, "letter": "D", "name": "Gariahat", "score": 78,
             "desc": "Shopping area • Good footfall • Moderate competition", "color": "#f5a524"},
            {"rank": 5, "letter": "E", "name": "New Town Action Area 1", "score": 74,
             "desc": "Upcoming area • Growing population • Good roads", "color": "#22c55e"},
        ],
        "scoreBreakdown": {
            "locationName": "Location A",
            "axes": [
                {"label": "Demand", "value": 95},
                {"label": "Accessibility", "value": 85},
                {"label": "Target Audience", "value": 90},
                {"label": "Competition (Inverted)", "value": 80},
                {"label": "Nearby Facilities", "value": 88},
            ],
        },
        "keyInsights": [
            {"icon": "fa-arrow-trend-up", "color": "green",
             "text": "Evening performance is strongest (4 PM - 10 PM). Ideal for dinner & hangout crowds."},
            {"icon": "fa-circle-info", "color": "blue",
             "text": "College proximity is a major demand driver in this area."},
            {"icon": "fa-triangle-exclamation", "color": "orange",
             "text": "Competition is moderate compared to popular commercial zones."},
            {"icon": "fa-subway", "color": "purple",
             "text": "Areas near metro stations show 18% higher footfall potential."},
        ],
        "dataOverview": [
            {"label": "Total Restaurants", "value": "1,248"},
            {"label": "Cafés", "value": "432"},
            {"label": "Colleges", "value": "35"},
            {"label": "Metro Stations", "value": "28"},
            {"label": "Avg. Population", "value": "12.4 L"},
        ],
    }


# ---------------------------------------------------------
# Demo-only user list for the /login endpoint.
# Replace this with a real database + hashed passwords before
# using this in production. This is here so the frontend has
# something to log in with while you build the real thing.
# ---------------------------------------------------------
DEMO_USERS = {
    "demo": "demo123",
    "admin": "admin123",
}
